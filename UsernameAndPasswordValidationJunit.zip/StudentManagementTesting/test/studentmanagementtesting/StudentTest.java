/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagementtesting;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Krish
 */
public class StudentTest {

    @Test
    public void testGradeA() {

        Student student = new Student();

        String result = student.calculateGrade(90);

        assertEquals("A", result);
    }

    @Test
    public void testGradeB() {

        Student student = new Student();

        String result = student.calculateGrade(70);

        assertEquals("B", result);
    }

    @Test
    public void testGradeC() {

        Student student = new Student();

        String result = student.calculateGrade(50);

        assertEquals("C", result);
    }

    @Test
    public void testFail() {

        Student student = new Student();

        String result = student.calculateGrade(30);

        assertEquals("Fail", result);
    }

    @Test
    public void testInvalidMarks() {

        Student student = new Student();

        String result = student.calculateGrade(110);

        assertEquals("Invalid", result);
    }
}