/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementtesting;

/**
 *
 * @author Krish
 */

public class Student {

    public String calculateGrade(int marks) {

        if (marks < 0 || marks > 100) {
            return "Invalid";
        }

        if (marks >= 80) {
            return "A";
        }
        else if (marks >= 60) {
            return "B";
        }
        else if (marks >= 40) {
            return "C";
        }
        else {
            return "Fail";
        }
    }
}

