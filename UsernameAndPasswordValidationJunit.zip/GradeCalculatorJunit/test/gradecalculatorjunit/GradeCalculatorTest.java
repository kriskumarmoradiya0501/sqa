/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package gradecalculatorjunit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Krish
 */
public class GradeCalculatorTest {

    @Test
    public void testGradeA() {
        GradeCalculator instance = new GradeCalculator();

        String result = instance.calculateGrade(90);

        assertEquals("A", result);
    }

    @Test
    public void testGradeB() {
        GradeCalculator instance = new GradeCalculator();

        String result = instance.calculateGrade(70);

        assertEquals("B", result);
    }

    @Test
    public void testGradeC() {
        GradeCalculator instance = new GradeCalculator();

        String result = instance.calculateGrade(50);

        assertEquals("C", result);
    }

    @Test
    public void testFail() {
        GradeCalculator instance = new GradeCalculator();

        String result = instance.calculateGrade(30);

        assertEquals("Fail", result);
    }

    @Test
    public void testBoundaryMarks() {
        GradeCalculator instance = new GradeCalculator();

        assertEquals("A", instance.calculateGrade(80));
        assertEquals("B", instance.calculateGrade(60));
        assertEquals("C", instance.calculateGrade(40));
        assertEquals("Fail", instance.calculateGrade(39));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidMarks() {
        GradeCalculator instance = new GradeCalculator();

        instance.calculateGrade(110);
    }
}