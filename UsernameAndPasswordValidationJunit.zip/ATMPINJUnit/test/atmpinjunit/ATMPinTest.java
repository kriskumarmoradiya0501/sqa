/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package atmpinjunit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Krish
 */
public class ATMPinTest {

    @Test
    public void testCorrectPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "1234");

        assertTrue(result);
    }

    @Test
    public void testIncorrectPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "5678");

        assertFalse(result);
    }

    @Test
    public void testAnotherIncorrectPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "1111");

        assertFalse(result);
    }

    @Test
    public void testShortPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "123");

        assertFalse(result);
    }

    @Test
    public void testLongPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "12345");

        assertFalse(result);
    }

    @Test
    public void testPINWithCharacters() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", "12ab");

        assertFalse(result);
    }

    @Test
    public void testNullPIN() {

        ATMPin instance = new ATMPin();

        boolean result = instance.checkPIN("1234", null);

        assertFalse(result);
    }
}