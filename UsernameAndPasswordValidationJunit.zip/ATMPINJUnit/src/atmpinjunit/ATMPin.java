/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Krish
 */

package atmpinjunit;

public class ATMPin {

    public boolean checkPIN(String storedPIN, String enteredPIN) {

        if (storedPIN == null || enteredPIN == null) {
            return false;
        }

        if (storedPIN.length() != 4 || enteredPIN.length() != 4) {
            return false;
        }

        if (!storedPIN.matches("[0-9]{4}") ||
            !enteredPIN.matches("[0-9]{4}")) {
            return false;
        }

        return storedPIN.equals(enteredPIN);
    }
}
