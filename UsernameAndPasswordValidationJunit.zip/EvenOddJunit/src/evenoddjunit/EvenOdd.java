package evenoddjunit;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Krish
 */
public class EvenOdd {
    public String checkEvenOdd(int number){
        if(number % 2 == 0){
            return "Even";
        }
        else{
            return "Odd";
        }
    }
}
