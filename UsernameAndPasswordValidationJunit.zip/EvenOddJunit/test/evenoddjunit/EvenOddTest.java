/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package evenoddjunit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Krish
 */
public class EvenOddTest {
    
    public EvenOddTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }



    /**
     * Test of checkEvenOdd method, of class EvenOdd.
     */
    @Test
    public void testCheckEven() {
        System.out.println("checkEvenOdd");
        int number = 10;
        EvenOdd instance = new EvenOdd();
        String expResult = "Even";
        String result = instance.checkEvenOdd(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    @Test
    public void testCheckOdd() {
        System.out.println("checkEvenOdd");
        int number = 7;
        EvenOdd instance = new EvenOdd();
        String expResult = "Odd";
        String result = instance.checkEvenOdd(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    @Test
    public void testCheckZero() {
        System.out.println("checkEvenOdd");
        int number = 0;
        EvenOdd instance = new EvenOdd();
        String expResult = "Even";
        String result = instance.checkEvenOdd(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
     @Test
    public void testCheckNagativeEven() {
        System.out.println("checkEvenOdd");
        int number = -10;
        EvenOdd instance = new EvenOdd();
        String expResult = "Even";
        String result = instance.checkEvenOdd(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
     @Test
    public void testCheckNagativeOdd() {
        System.out.println("checkEvenOdd");
        int number = -7;
        EvenOdd instance = new EvenOdd();
        String expResult = "Odd";
        String result = instance.checkEvenOdd(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
        
}
