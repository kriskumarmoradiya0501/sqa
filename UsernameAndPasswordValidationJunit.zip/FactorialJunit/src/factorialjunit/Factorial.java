/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factorialjunit;

/**
 *
 * @author Krish
 */
public class Factorial {
    public long calculateFactorial(int number){
        if(number < 0){
            throw new IllegalArgumentException("Factorial is not defined for negative numbers");
        }
        
        long factorial = 1;
        
        for(int i = 1; i<= number ; i++){
            factorial = factorial * i;
        }
        return factorial;
        
    }
}
