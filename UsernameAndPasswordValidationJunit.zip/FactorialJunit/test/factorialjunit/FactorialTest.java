
package factorialjunit;

import org.junit.Test;
import static org.junit.Assert.*;

public class FactorialTest {

    // TC01: Factorial of zero
    @Test
    public void testCalculateFactorialZero() {

        int number = 0;

        Factorial instance = new Factorial();

        long expResult = 1;
        long result = instance.calculateFactorial(number);

        assertEquals(expResult, result);
    }

    // TC02: Factorial of one
    @Test
    public void testCalculateFactorialOne() {

        int number = 1;

        Factorial instance = new Factorial();

        long expResult = 1;
        long result = instance.calculateFactorial(number);

        assertEquals(expResult, result);
    }

    // TC03: Factorial of five
    @Test
    public void testCalculateFactorialFive() {

        int number = 5;

        Factorial instance = new Factorial();

        long expResult = 120;
        long result = instance.calculateFactorial(number);

        assertEquals(expResult, result);
    }

    // TC04: Factorial of three
    @Test
    public void testCalculateFactorialThree() {

        int number = 3;

        Factorial instance = new Factorial();

        long expResult = 6;
        long result = instance.calculateFactorial(number);

        assertEquals(expResult, result);
    }

    // TC05: Factorial of negative number
    @Test(expected = IllegalArgumentException.class)
    public void testNegativeFactorial() {

        Factorial instance = new Factorial();

        instance.calculateFactorial(-5);
    }
}
