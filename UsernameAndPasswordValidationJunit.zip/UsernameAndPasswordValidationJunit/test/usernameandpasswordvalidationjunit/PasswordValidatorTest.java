/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package usernameandpasswordvalidationjunit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Krish
 */
public class PasswordValidatorTest {

    @Test
    public void testValidCredentials() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "Kris@123");

        assertTrue(result);
    }

    @Test
    public void testPasswordWithoutUppercase() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "kris@123");

        assertFalse(result);
    }

    @Test
    public void testPasswordWithoutLowercase() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "KRIS@123");

        assertFalse(result);
    }

    @Test
    public void testPasswordWithoutDigit() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "Kris@abc");

        assertFalse(result);
    }

    @Test
    public void testPasswordWithoutSpecialCharacter() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "Kris1234");

        assertFalse(result);
    }

    @Test
    public void testShortPassword() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "kris123", "Kr@1");

        assertFalse(result);
    }

    @Test
    public void testShortUsername() {

        PasswordValidator instance = new PasswordValidator();

        boolean result = instance.validateCredentials(
                "abc", "Kris@123");

        assertFalse(result);
    }
}